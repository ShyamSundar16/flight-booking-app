export class Schedule {
    id: string="";
    code: string = "";
    scheduledDate: string = "";  
    arrivalTime: string = "";  
    depatureTime: string = "";  
    status: string = "";
    availabeEconomyTickets:number=0;
    availabeBusinessTickets:number=0;
}


