export class Coupon {
    id: number=0;
    code: string = "";
    couponValue:number =0;
    status: string = "";
    validTill: Date = new Date();  
}


