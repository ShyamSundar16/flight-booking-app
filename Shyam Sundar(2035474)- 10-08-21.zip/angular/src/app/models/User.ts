export class User{
    id:string="";
    valid:boolean = false;
    name:string = "";
    email:string="";
    phone?:number=0;
    password:string="";
}