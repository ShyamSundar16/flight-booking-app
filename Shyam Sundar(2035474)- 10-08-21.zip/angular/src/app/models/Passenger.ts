export class Passenger {
    id: string = "";
    name: string = "";
    gender: string = "";
    age: number = 0;
    optedFood: string = "";
    seatNumber: string = "";
    travelClass:string="";
}